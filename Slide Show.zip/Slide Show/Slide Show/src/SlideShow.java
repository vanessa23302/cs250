import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.net.URI;
import java.util.Arrays;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Desktop;

public class SlideShow extends JFrame {

	//Declare Variables
	private JPanel slidePane = new JPanel();
	private JPanel textPane = new JPanel();
	private JPanel buttonPane = new JPanel();
	private JPanel southPane = new JPanel();
	private CardLayout card = new CardLayout();
	private CardLayout cardText = new CardLayout();
	private JButton btnPrev = new JButton();
	private JButton btnNext = new JButton();


	private List<Slide> slides = Arrays.asList(
	new Slide(
			"<font size='5'>#1 The BARAI Spa, Thailand</font> <br>An award winning destination Spa with 18 remarkable treatment rooms and 8 exclusive residential spa suites located on more than 4.5 acres of serene beach.",
			"/resources/slide1.jpg", 
			"https://thebarai.com/"),
	new Slide(
			"<font size='5'>#2 Sianji Well-Being Resort, Turkey</font> <br>Intensive detox retreat, situated in a secluded coastal area of Turkey.",
			"/resources/slide2.jpg",
			"https://sianjilife.com/en/"),
	new Slide(
			"<font size='5'>#3 Lefay Resort & Spa, Italy</font> <br> Transform your body with healthy nutrition, holistic therapies and toxin cleansing exercise.",
			"/resources/slide3.jpg",
			"https://lagodigarda.lefayresorts.com/en"),
	new Slide(
			"<font size='5'>#4 Ananda in the Himalayas, India</font> <br> With spa treatments, ranging from aromatherapy massages to detoxifying salt scrubs, return home from this luxury detox retreat revived and rejuvenated.",
			 "/resources/slide4.jpg",
			 "https://www.anandaspa.com/en/programmes?gad_source=1&gad_campaignid=6445658352&gbraid=0AAAAACrOLLyv0AAaJ7CUsBkWevF4Vs8qL&gclid=EAIaIQobChMIsJ_t_abjjQMVGFR_AB06qx6_EAAYAiAAEgLc0fD_BwE"),
	new Slide(
			"<font size='5'>#5 Euphoria Retreat, Greece</font> <br> Euphoria Retreat, a leading wellbeing destination spa hotel.",
			"/resources/slide5.jpg",
			"https://www.euphoriaretreat.com/")
	);
	/**
	 * Create the application.
	 */
	public SlideShow() throws HeadlessException {
		initComponent();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initComponent() {
		//Initialize variables to empty objects
		
		//configure components/controls 
		textPane.setBackground(Color.WHITE);
		textPane.setBounds(5, 470, 790, 50);
		textPane.setVisible(true);
		southPane.setLayout(new BoxLayout(southPane, BoxLayout.Y_AXIS));
		
		//Setup frame attributes
		setSize(800, 600);
		setLocationRelativeTo(null);
		setTitle("Top 5 Destinations SlideShow");
		getContentPane().setLayout(new BorderLayout(10, 50));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		//Setting the layouts for the panels
		slidePane.setLayout(card);
		textPane.setLayout(cardText);
		
		//logic to add each of the slides and text
		slides.forEach(s -> {
			final JLabel imageLabel = new JLabel(s.getImage());
			imageLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent evt) {
			try {
			 Desktop.getDesktop().browse(URI.create(s.getUrl()));
			} catch(IOException e) {
				e.printStackTrace();
			}
			}
			});
			slidePane.add(imageLabel);
			textPane.add(new JLabel(s.getDescription()));	
		});
		
		getContentPane().add(slidePane, BorderLayout.CENTER);
		southPane.add(textPane);

		buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));

		btnPrev.setText("Previous");
		btnPrev.addActionListener((ActionEvent e) -> goPrevious());
		buttonPane.add(btnPrev);

		btnNext.setText("Next");
		btnNext.addActionListener((ActionEvent e) -> goNext());
		buttonPane.add(btnNext);

		southPane.add(buttonPane);
		
		getContentPane().add(southPane, BorderLayout.SOUTH);	}

	/**
	 * Previous Button Functionality
	 */
	private void goPrevious() {
		card.previous(slidePane);
		cardText.previous(textPane);
	}
	
	/**
	 * Next Button Functionality
	 */
	private void goNext() {
		card.next(slidePane);
		cardText.next(textPane);
	}


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(() -> (new SlideShow()).setVisible(true));
			}
	
	class Slide {
		private final String description;
		private final String image;
		private final String url;
		
		public Slide(final String description, final String image, final String url) {
			super();
			this.description = "<html><body>" + description + "</body></html>";
			this.image = "<html><body><img width= '800' height='500' src='" + getClass().getResource(image) + "'</body></html>";
			this.url = url;
		}

		public String getDescription() {
			return description;
		}

		public String getImage() {
			return image;
		}

		public String getUrl() {
			return url;
		}
		
		
	}
		}